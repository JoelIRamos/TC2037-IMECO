(+ -8/2 2.4e10 -89 0.78 -2.0e-1)
[foo]
{fn}
;; Comentario buenp
\c
"Cadena de texto"
#"[Regex]"
#/4._Error_o[
(Aqui [hay] un^/ error)