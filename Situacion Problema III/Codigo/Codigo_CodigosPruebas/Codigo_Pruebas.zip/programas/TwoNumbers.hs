twoNumbers :: (Double Double) 
twoNumbers = (3.14 2.59) 
address :: (String Int String Int) 
address = ("New York" 10005 "Wall St." 1) 
main = do  
  print twoNumbers  
  print address 