-- Type annotation (optional, same for each implementation) 
quickSort :: Ord a => [a] -> [a]  