sayTwice :: String -> String 
sayTwice s = s ++ s 
main = print (sayTwice "hello") 